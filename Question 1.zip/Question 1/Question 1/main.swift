//
//  main.swift
//  Question 1
//
//  Created by Lavpreet Kaur on 2017-10-13.
//  Copyright © 2017 Lavpreet Kaur. All rights reserved.
//

import Foundation


var employee = Employee(Name: "lav", Country: "india", Benefit: "rt" )
var partTime = PartTime(Name: "lav", Country: "india", Benefit: "rt", Hours : 100.0, Rate : 10.0  )
var fullTime = FullTime(Name: "lav", Country: "india", Benefit: "rt" , Salary : 10000.0, Bonus : 500.0)


print ("Name : \(employee.getName()), Country : \(employee.getCountry()), Benefit : \(employee.getBenefit()) , Earnings : \(employee.CalculateEarnings())")

print ("Name : \(partTime.getName()), Country : \(partTime.getCountry()), Benefit : \(partTime.getBenefit()) , Earnings : \(partTime.CalculateEarnings())")

print ("Name : \(fullTime.getName()), Country : \(fullTime.getCountry()), Benefit : \(fullTime.getBenefit()) , Earnings : \(fullTime.CalculateEarnings())")



