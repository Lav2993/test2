//
//  employee.swift
//  Question 1
//
//  Created by Lavpreet Kaur on 2017-10-13.
//  Copyright © 2017 Lavpreet Kaur. All rights reserved.
//

import Foundation
class Employee{
    public private(set) var name:String = ""
    public private(set) var country:String = ""
    public private(set) var benefit:String = ""
    public private (set) var earnings : Double = 0.0
    
    
    public func getName () -> String
    {
        return name
    }
    
    public func getCountry () -> String
    {
        return country
    }
    public func getBenefit () -> String
    {
        return benefit
    }
    
    
    public func setName (name:String) {
        self.name = name
    }
    
    public func setCountry (country:String) {
        self.country = country
    }
    
    public func setBenefit (benefit:String) {
        self.benefit = benefit
    }
    init (Name:String, Country: String, Benefit: String, Earnings:Double){
        self.name = Name
        self.country = Country
        self.benefit = Benefit
        self.earnings = Earnings
    }
    func CalculateEarnings() {
        earnings = 1000
        print ("earnings \(earnings)")
        

    }
    public var description: String {
        return "Employee: name - \(name), Country - \(country), Benefit - \(benefit), Earnings - \(earnings)"
    }
    
    
    
    
    
}
class FullTime: Employee{
    public private (set) var salary : Double = 0.0
    public private (set) var bonus : Double = 0.0
    
    
    public func getSalary () -> Double
    {
        return salary
    }
    
    public func getBonus () -> Double
    {
        return bonus
    }
    
    
    public func setbonus (bonus:Double) {
        self.bonus = bonus
    }
    
    public func setsalary (salary:Double) {
        self.salary = salary
    }
    
    override func CalculateEarnings(bonus:Double, salary:Double, n:Double) -> Double {
        return salary+bonus
        
    
    }
    override public var description: String {
        return "Employee: name - \(name), Country - \(country), Benefit - \(benefit), Earnings - \(earnings) "
    }
    
    
}


class PartTime: Employee{
    public private (set) var hours : Double = 0.0
    public private (set) var rate : Double = 0.0
    
    
    public func getHours () -> Double
    {
        return hours
    }
    
    public func getRate () -> Double
    {
        return rate
    }
    
    
    public func setHours (hours:Double) {
        self.hours = hours
    }
    
    public func setRate (rate:Double) {
        self.rate = rate
    }
    func CalculateEarnings( hours:Double, rate:Double) -> Double {
        return hours*rate
        
    
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

